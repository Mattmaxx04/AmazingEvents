# AmazingEvents



[![](assets/amazinge.svg)]()

_Amazing Events._
_Se realizan diferentes páginas solicitadas por el cliente. El sitio es totalmente responsive y dinámico._
_Cuenta con un buscador por texto, y un filtro por categoría mediante switchs, ambos funcionan en simultaneo._

 [![](assets/amazing1.png)]()
 [![](assets/amazing2.png)]()
 
*Podés visitar [AmazingEvents](https://amazing-events-site.netlify.app).*
